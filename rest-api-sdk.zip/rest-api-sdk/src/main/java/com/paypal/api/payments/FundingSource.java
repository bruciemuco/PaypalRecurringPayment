package com.paypal.api.payments;

import com.paypal.base.rest.JSONFormatter;

public class FundingSource  {

	/**
	 * Default Constructor
	 */
	public FundingSource() {
	}

}
