package com.paypal.api.payments;

import com.paypal.base.rest.JSONFormatter;

public class Percentage  {

	/**
	 * Default Constructor
	 */
	public Percentage() {
	}

}
