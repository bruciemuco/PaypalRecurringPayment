package com.paypal.api.payments;

import com.paypal.base.rest.JSONFormatter;
import com.paypal.base.rest.PayPalModel;

public class BillingAgreementToken extends PayPalModel{

	/**
	 * Default Constructor
	 */
	public BillingAgreementToken() {
	}

}
