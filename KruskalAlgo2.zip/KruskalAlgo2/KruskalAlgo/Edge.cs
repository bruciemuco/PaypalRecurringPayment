﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KruskalAlgo
{
    class Edge
    {
        public Vertex Source { get; set; }
        public Vertex Destination { get; set; }
        public int weight { get; set; }
        public Edge(Vertex src, Vertex dest, int wt)
        {
            Source = src;
            Destination = dest;
            weight = wt;
        }
        public Edge()
        {
        }
    }
}
