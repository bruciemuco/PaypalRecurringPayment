﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KruskalAlgo
{
    class Set
    {
        public Vertex parent { get; set; }
        public int rank { get; set; }
    }
}
