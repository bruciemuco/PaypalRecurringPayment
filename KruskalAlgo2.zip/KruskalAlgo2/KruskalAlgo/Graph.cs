﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KruskalAlgo
{
    class Graph
    {
        public List<Edge> Edgecoll = null;
        public Vertex[] vertcoll = null;
        Vertex v = null;
        
        public Graph(int size)
        {
            vertcoll = new Vertex[size];

        }
    }
}
