﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KruskalAlgo
{
    class Program
    {
        private static int vert;

        static void Main(string[] args)
        {
            int counter = 0;
            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\mucob\Documents\Visual Studio 2015\Projects\readFile\readFile\AdjacencyMatrix_of_Graph_G_N_10.txt");
            foreach (string line in lines)
            {
                string[] stringSeparators = new string[] { "    " };
                //split the line into array elements
                string[] split = line.Split(stringSeparators, StringSplitOptions.None);


                counter = (split.Length-1);
            }


            vert = counter;
            Graph graph = new Graph(counter);

            for (int count = 0; count < counter; count++)
            {
                int label = count+1;
                Vertex a = new Vertex();
                a.Label = label.ToString();
                graph.vertcoll[count] = a;
            }
            graph.Edgecoll = new List<Edge>();
            Edge[] result = new Edge[vert];

           
            // Display the file contents by using a foreach loop.
            System.Console.WriteLine("Contents of WriteLines2.txt = ");
            
            int source = 0;


            foreach (string line in lines)
            {
                string[] stringSeparators = new string[] { "    " };
                //split the line into array elements
                string[] split = line.Split(stringSeparators, StringSplitOptions.None);

                for (int destination = 1; destination < split.Length; destination++) {

                    int weight = int.Parse(split[destination]);

                    int dest = destination - 1;
                    
                    Edge edge1 = new Edge(graph.vertcoll[dest], graph.vertcoll[source], weight);
                    graph.Edgecoll.Add(edge1);
                }
                
                source++;
                // Use a tab to indent each line of the file.
                Console.WriteLine("\t" + line);
            }


            
            

            //sort the edges by their values fron the smallest to the largest.
            graph.Edgecoll.Sort(
                delegate (Edge edge_1, Edge edge_2)
            {
                return edge_1.weight.CompareTo(edge_2.weight);
            });

            foreach (Edge _edge in graph.Edgecoll)
            {
                Console.WriteLine("Edge : ("+_edge.Destination.Label+" "+ _edge.Source.Label+").  value: "+ _edge.weight);
                Console.WriteLine();
            }

            //create minimum spanning tree
            Set[] sub = new Set[vert];
            Set subobj;
            for (int x = 0; x < vert; x++)
            {
                subobj = new Set();
                subobj.parent = graph.vertcoll[x];
                subobj.rank = 0;
                sub[x] = subobj;
            }
            int k = 0;
            int _e = 0;
            Edge edge = new Edge();
            while (_e < vert - 1)
            {
                edge = graph.Edgecoll.ElementAt(k);
                Vertex x = find(sub, edge.Destination, Array.IndexOf(graph.vertcoll, edge.Destination), graph.vertcoll);
                Vertex y = find(sub, edge.Source, Array.IndexOf(graph.vertcoll, edge.Source), graph.vertcoll);
                if (x != y)
                {
                    result[_e] = edge;
                    Union(sub, x, y, graph.vertcoll);
                    _e++;
                }
                k++;


            }

            for (int x = 0; x < _e; x++)
            {
                Console.WriteLine("edge from src:{0} to dest:{1} with weight:{2}", result[x].Destination.Label, result[x].Source.Label, result[x].weight);
            }

            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
        private static void Union(Set[] sub, Vertex xr, Vertex yr, Vertex[] vertex)
        {
            Vertex x = find(sub, xr, Array.IndexOf(vertex, xr), vertex);
            Vertex y = find(sub, yr, Array.IndexOf(vertex, yr), vertex);

            if (sub[Array.IndexOf(vertex, x)].rank < sub[Array.IndexOf(vertex, y)].rank)
            {
                sub[Array.IndexOf(vertex, x)].parent = y;
            }
            else if (sub[Array.IndexOf(vertex, x)].rank > sub[Array.IndexOf(vertex, y)].rank)
            {
                sub[Array.IndexOf(vertex, y)].parent = x;
            }
            else
            {
                sub[Array.IndexOf(vertex, y)].parent = x;
                sub[Array.IndexOf(vertex, x)].rank++;
            }
        }

        private static Vertex find(Set[] sub, Vertex vertex, int k, Vertex[] vertdic)
        {
            if (sub[k].parent != vertex)
            {
                sub[k].parent = find(sub, sub.ElementAt(k).parent, Array.IndexOf(vertdic, sub.ElementAt(k).parent), vertdic);// find(sub, vertex, Array.IndexOf(vertdic,vertex),vertdic);//sub.Select(j => j.parent).Where(v => v.Label == vertex.Label).FirstOrDefault();
            }

            return sub[k].parent;
        }

    }
}
